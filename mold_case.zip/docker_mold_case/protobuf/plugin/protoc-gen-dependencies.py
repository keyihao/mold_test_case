#!/usr/bin/env python
# coding=utf-8
import os
import sys
from google.protobuf.compiler import plugin_pb2 as plugin

PYTHON_VERSION = 2
if (getattr(sys.version_info, "major", None) == 3) or (sys.version_info[0] == 3):
    PYTHON_VERSION = 3

PROTO_PREFIX = "google/protobuf"
REPLACED_PROTO_PREFIX = "mm3rd/protobuf/src/%s" % (PROTO_PREFIX)


def replace_google_proto_prefix(proto_name):
    if proto_name.startswith(PROTO_PREFIX):
        proto_name = proto_name.replace(PROTO_PREFIX, REPLACED_PROTO_PREFIX)
    return proto_name


def generate_code(request, response):
    proto_key = ".proto"
    current_file_list = list(request.file_to_generate)
    current_file_dir = "tmp"
    current_file_name = ""
    if current_file_list:
        current_file_path = current_file_list[0]
        current_file_name = os.path.basename(current_file_path)
        current_file_dir = os.path.dirname(current_file_path)

    dependencies_name = current_file_name.replace(proto_key, ".deps")
    dependencies_path = os.path.join(current_file_dir, dependencies_name)

    dependencies_graph_name = current_file_name.replace(proto_key, ".deps.graph")
    dependencies_grapb_path = os.path.join(current_file_dir, dependencies_graph_name)

    data = ""
    proto_name_list = []
    # 1. 所有的proto_file文件
    proto_file = request.proto_file
    proto_file = list(proto_file)

    for item in proto_file:
        # (1)当前的proto文件名
        proto_name = item.name
        proto_name = replace_google_proto_prefix(proto_name)

        # (2)当前proto文件中的直接依赖
        dependencies = list(item.dependency)
        for index, dependency in enumerate(dependencies):
            dependency = replace_google_proto_prefix(dependency)
            dependencies[index] = dependency

        dependency_str = "[%s]" % (",".join(dependencies))
        proto_name_list.append(proto_name)
        data = "%s\n%s:%s" % (data, proto_name, dependency_str)

    # 2. 存储依赖信息到产出目录
    # (1) 依赖文件名: dependencies.txt
    proto_name_list = list(set(proto_name_list))
    proto_name_list.sort()

    data_str = "\n".join(proto_name_list)
    response.file.add()

    # response.file[0].name = 'dependencies.txt'
    response.file[0].name = dependencies_path
    response.file[0].content = data_str

    # (2) 依赖图: dependencies_graph.txt
    response.file.add()
    response.file[1].name = dependencies_grapb_path
    response.file[1].content = data


def main():
    # Read request message from stdin
    if PYTHON_VERSION == 3:
        data = sys.stdin.buffer.read()
    else:
        data = sys.stdin.read()

    # Parse request
    request = plugin.CodeGeneratorRequest()
    request.ParseFromString(data)
    # Create response
    response = plugin.CodeGeneratorResponse()
    # Generate code
    generate_code(request, response)
    # Serialise response message
    output = response.SerializeToString()
    # Write to stdout
    # sys.stdout.buffer.write()
    # For python3
    if PYTHON_VERSION == 3:
        sys.stdout.buffer.write(output)
    else:
        sys.stdout.write(output)


if __name__ == "__main__":
    main()
