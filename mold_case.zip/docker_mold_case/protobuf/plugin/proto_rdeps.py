#!/usr/bin/env python
# coding=utf-8
import argparse
import subprocess
import sys
import os
import datetime
import json
# time python /home/tabnine/QQMail/mm3rd/protobuf/plugin/proto_rdeps.py --base-dir mmproto --proto-file mmproto/csproto/finder/mmfinderlivepromotion/finderwindowproductinfo.proto
# 要求worksapce下有mm3rd/protobuf，切换到Master分支


def bytes_decode(msg):
    if (getattr(sys.version_info, "major", None) == 2) or (sys.version_info[0] == 2):
        if type(msg).__name__ == "unicode":
            msg = msg.encode("utf-8")
    else:
        if type(msg).__name__ == "bytes":
            msg = msg.decode("utf-8")
    return msg


def catch_err(func):
    """
    rtn用来判断有没有try catch的错误
    """
    def out(*args, **kwargs):
        result = {"rtn": 0, "msg": ""}
        try:
            func_result = func(*args, **kwargs)
            if func_result:
                result.update(func_result)
        except (IOError, ValueError, TypeError, KeyError, PermissionError) as e:
            result["rtn"] = 1
            msg = "Error with " + func.__name__ + ":" + str(e)
            result["msg"] = msg
        return result

    return out


@catch_err
def exe_cmd(cmd, cwd=None, shell=True):
    # log_info(cmd, cwd)
    pro = subprocess.Popen(
        cmd, shell=shell, stdout=subprocess.PIPE,
        stderr=subprocess.PIPE, cwd=cwd
    )
    std_out, std_err = pro.communicate()
    return_code = pro.returncode
    std_out = bytes_decode(std_out)
    std_err = bytes_decode(std_err)
    log_debug(cmd, cwd)

    result = {"rtn": return_code, "msg": std_err, "std_out": std_out}

    return result


def log_info(*args):
    msg = ""
    for arg in args:
        msg = msg + " " + str(arg)
    msg = "\033[1;36m" + msg + "\033[0m"
    print(msg)


def log_debug(*args):
    msg = ""
    for arg in args:
        msg = msg + " " + str(arg)
    msg = "\033[1;32m" + msg + "\033[0m"
    print(msg)


def log_err(*args):
    msg = ""
    for arg in args:
        msg = msg + " " + str(arg)
    msg = "\033[1;31m" + msg + "\033[0m"
    print(msg)


def log_warning(*args):
    msg = ""
    for arg in args:
        msg = msg + " " + str(arg)
    msg = "\033[1;33m" + msg + "\033[0m"
    print(msg)


def get_current_time_str(time_format='%Y-%m-%d-%H-%M-%S'):
    # 当前时间的str
    current_time = datetime.datetime.now().strftime(time_format)
    return current_time


def store_json(file_name, data, base_dir):
    file_path = file_name
    if base_dir:
        file_path = os.path.join(base_dir, file_name)

    with open(file_path, "w+") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
        log_debug("store json data into %s, len(data) = %s" %
                  (file_path, len(data)))


def find_dependencies_out_dir(workspace, out_dir):
    # 1. 获取输出目录

    if not out_dir:
        out_dir = os.path.join(
            workspace, "dependencies_out/"+get_current_time_str())
    if not os.path.exists(out_dir):
        log_debug("Generating dependencies out dir ", out_dir)
        os.makedirs(out_dir)
    return out_dir


class CmdParser(object):
    def __init__(self):
        description = "找dir目录下proto文件的反向依赖."
        argparser = argparse.ArgumentParser(description)
        argparser.add_argument(
            "--base-dir",
            dest="base_dir",
            required=True,
            help="要查询的proto相对于QQMail的目录",
        )

        argparser.add_argument(
            "--proto-file",
            dest="proto_file",
            required=True,
            help="proto相对路径",
        )

        default_root = os.path.join(os.environ["HOME"], "QQMail")
        argparser.add_argument(
            "--workspace",
            dest="workspace",
            default=default_root,
            help="QQMail",
        )
        argparser.add_argument(
            "--out-dir",
            dest="out_dir",
            default="",
            help="QQMail",
        )

        self.options, self.args = argparser.parse_known_args()
        self.argparser = argparser

    def print_help(self):
        self.argparser.print_help()


class GetRdepsOfProto(object):
    def __init__(self, workspace, base_dir_list, proto_file, out_dir):
        self.workspace = workspace
        self.base_dir_list = base_dir_list
        self.proto_file = proto_file
        self.out_dir = out_dir
        pass

    def _find_proto_under_dir(self, base_dir):
        proto_list = []
        cmd = 'find ./ -name "*\.proto"'
        work_dir = os.path.join(self.workspace, base_dir)
        result = exe_cmd(cmd, work_dir)
        rtn = result['rtn']
        msg = result['msg']

        if rtn:
            return rtn, msg, proto_list
        std_out = result['std_out']
        lines = std_out.split("\n")

        for line in lines:
            line = line.strip()
            if line:
                proto_path = os.path.join(base_dir, line)
                proto_path = os.path.normpath(proto_path)
                proto_list.append(proto_path)
        return rtn, msg, proto_list

    def _generate_dependencies_for_proto(self,  proto_list, out_dir):

        # 2. 查找依赖`工具相关`的参数
        protobuf_dir = os.path.join(self.workspace, "mm3rd/protobuf")
        protoc_path = os.path.join(protobuf_dir, "bin/protoc")
        google_include_dir = os.path.join(protobuf_dir, "src")
        dependency_plugin_path = os.path.join(
            protobuf_dir, "plugin/protoc-gen-dependencies.py")

        # 3. 运行查找依赖命令
        failed_proto_dict = {}
        success_proto_list = []

        for proto_path in proto_list:

            cmd = "%s --plugin=protoc-gen-dependencies=%s -I%s -I. --dependencies_out=%s %s" % (
                protoc_path, dependency_plugin_path, google_include_dir, out_dir, proto_path
            )
            result = exe_cmd(cmd, self.workspace)
            rtn = result['rtn']
            if rtn:
                msg = result['msg']
                failed_proto_dict[proto_path] = msg
            else:
                success_proto_list.append(proto_path)

        return success_proto_list, failed_proto_dict

    def _find_rdeps_for_proto(self, out_dir, proto_file):
        rdeps_list = []
        cmd = 'grep -rnHl "%s" --include="*\.deps"' % proto_file
        result = exe_cmd(cmd, out_dir)
        rtn = result['rtn']
        msg = ""
        if not rtn:
            msg = result['msg']
            std_out = result['std_out']
            lines = std_out.splitlines()
            rdeps_list = []
            for line in lines:
                line = line.strip()
                proto_dir = line.rstrip(".deps")
                rdeps_proto_path = "%s.proto" % (proto_dir)
                rdeps_list.append(rdeps_proto_path)
            rdeps_list = list(set(rdeps_list))
        return rtn, msg, rdeps_list

    def process(self,):
        rdeps_list = []
        proto_list = []
        result = {}
        # 1. 查询目录下的proto列表
        for base_dir in self.base_dir_list:
            work_dir = os.path.join(self.workspace, base_dir)
            # a. 目录是否存在
            if not os.path.exists(work_dir):
                rtn = 1
                msg = "目录 %s 不存在" % (work_dir)
                log_err("测试12 ", rtn, msg)
                break
            # b. 目录下查询proto列表
            rtn, msg, sub_proto_list = self._find_proto_under_dir(base_dir)
            log_info("目录 %s 下有proto文件 %s 个" % (work_dir, len(sub_proto_list)))
            if rtn:
                msg = "查询proto文件失败:dir=%s, msg = %s" % (work_dir, msg)
                log_err("测试122 ", rtn, msg)
                break
            # c. 添加proto列表
            proto_list.extend(sub_proto_list)

        if not rtn:
            log_info("目录列表 %s 下共有proto文件 %s 个" %
                     (self.base_dir_list, len(proto_list)))

            # 2. 找每个proto文件的依赖信息
            out_dir = self.out_dir
            success_proto_list, failed_proto_dict = self._generate_dependencies_for_proto(
                proto_list, out_dir)

            # 3. 找到proto_path 的反向依赖
            _rtn, msg, rdeps_list = self._find_rdeps_for_proto(
                out_dir, self.proto_file)

            result = {
                "failed_proto": failed_proto_dict,
                "success_proto": success_proto_list
            }
        return rtn, msg, rdeps_list, result


def main():
    cmd_parser = CmdParser()
    workspace = cmd_parser.options.workspace
    base_dirs = cmd_parser.options.base_dir
    base_dir_list = list(set(base_dirs.split(",")))

    proto_file = cmd_parser.options.proto_file
    input_out_dir = cmd_parser.options.out_dir
    out_dir = find_dependencies_out_dir(workspace, input_out_dir)

    obj = GetRdepsOfProto(workspace, base_dir_list, proto_file, out_dir)
    # failed_proto_dict: protoc报错的proto及报错原因
    # success_proto_list: 依赖查询成功的proto列表
    rtn, msg, rdeps_list, res = obj.process()
    success_proto_list = []
    if not rtn:
        # a. protoc成功的列表
        failed_proto_dict = res.get("failed_proto", {})
        failed_proto_dict_path = "failed_proto_dict.json"
        store_json(failed_proto_dict_path, failed_proto_dict, out_dir)
        # b. protoc失败的文件列表及原因
        success_proto_list = res.get("success_proto", [])
        success_proto_list_path = "success_proto_list.json"
        store_json(success_proto_list_path, success_proto_list, out_dir)
        # c. 脚本运行的参数和结果
        rdeps_list_path = 'rdeps_list.json'
        data = {
            "proto_file": proto_file,
            "rdeps_list": rdeps_list,
            "base_dir": base_dir_list,
            "workspace": workspace,
            "failed_proto_len": len(failed_proto_dict),
            "success_proto_len": len(success_proto_list)
        }
        store_json(rdeps_list_path, data, out_dir)
        log_info("len(rdeps) of %s under %s: %s, result store_dir = %s" %
                     (proto_file, base_dir_list, len(rdeps_list), out_dir))
    else:
        log_err("Error with find_rdeps, rtn =%s, msg = %s" % (rtn, msg))
    log_warning(rtn, msg, len(rdeps_list), len(success_proto_list))
    exit(rtn)


if __name__ == "__main__":
    main()
